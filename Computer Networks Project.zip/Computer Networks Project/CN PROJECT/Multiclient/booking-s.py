import socket
import csv
import pandas as pd
import numpy as np
from csv import writer
from _thread import *

df = pd.read_csv("C:/Users/SIDHARTH/Downloads/Flights.csv")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((socket.gethostname(), 1024))
s.listen(10)
list1=[]
def threaded_client(clt):
    while True:
        ch = clt.recv(10).decode("utf-8")
        if(ch == 'I'):
            n = clt.recv(10).decode("utf-8")
            for i in range(1, int(n)+1):
                clt.send(bytes("From :", "utf-8"))
                From = clt.recv(1000).decode("utf-8")
                
                clt.send(bytes("To", "utf-8"))
                To = clt.recv(1000).decode("utf-8")
                
                clt.send(bytes("Flight: ", "utf-8"))
                Flight = clt.recv(1000).decode("utf-8")
                
                clt.send(bytes("Departure Time: ", "utf-8"))
                Departure_time = clt.recv(1000).decode("utf-8")
                
                clt.send(bytes("Ticket_cost: ", "utf-8"))
                Ticket_cost = clt.recv(1000).decode("utf-8")
                
                list1=[From,To,Flight,Departure_time,Ticket_cost]
                with open("C:/Users/SIDHARTH/Downloads/Flights.csv",'a', newline='') as csvfile:
        
                    writer = csv.writer(csvfile)
                    writer.writerow(list1)
        elif(ch == 'V'):
            clt.send(bytes("C:/Users/SIDHARTH/Downloads/Flights.csv","utf-8"))
            
            
                
                        
while True:
    clt, adr = s.accept()
    print(f"Connection established to {adr}")
    start_new_thread(threaded_client, (clt, ))
    clt.send(bytes("Input I for Insertion\nM for Modification\nV for View\nU for Updating\n\n", "utf-8"))
    
    




    


