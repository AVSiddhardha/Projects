import socket
import pandas as pd
import numpy as np
df = pd.read_csv(r"C:/Users/SIDHARTH/Downloads/Flights.csv")
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((socket.gethostname(), 1024))
ch = input(s.recv(1000).decode("utf-8"))
s.send(ch.encode("utf-8"))
if(ch == 'I'):
    n = int(input("Enter number of rows to be inserted :"))
    s.send(str(n).encode("utf-8"))
    for i in range(1, n + 1):
        From = input(s.recv(1000).decode("utf-8"))
        s.send(From.encode("utf-8"))
        
        To = input(s.recv(1000).decode("utf-8"))
        s.send(To.encode("utf-8"))
        
        Flight = input(s.recv(1000).decode("utf-8"))
        s.send(Flight.encode("utf-8"))
        
        Departure_time = input(s.recv(1000).decode("utf-8"))
        s.send(Departure_time.encode("utf-8"))
        
        Ticket_cost = input(s.recv(1000).decode("utf-8"))
        s.send(Ticket_cost.encode("utf-8"))
        
elif(ch == 'V'):
    print(pd.read_csv(s.recv(5000).decode("utf-8")))

        
        


