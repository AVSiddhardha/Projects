# userInterfaceDesign_Project
An e-commerce website which focuses on suitings and styling.
The order placement system basically works as a form which is linked to Google API (forms & spreadsheet)
This way the project actually manages a front to end solution and can be hosted on the domain .
The images would actually be missing but you get the point right ?
Check out this project . 
Thank you !
